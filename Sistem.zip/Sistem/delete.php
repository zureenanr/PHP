<?php
//sambung ke pangkalan data
require ('config.php');
//memastikan pengguna login terlebih dahulu
include('pengesahan_guru.php');
//Dapatkan ID dari URL
$ndp = $_GET['ndp'];
//Hapus rekod pelajar semasa
$result = mysqli_query($samb, "DELETE FROM  WHERE ndp='$ndp'");
//Papar mesej jika berjaya hapus
echo "<script>alert('Hapus maklumat berjaya');
window.location= 'senarai_pelajar.php'</script>";
?>