<?php
include "config.php";
if (isset($_POST['ndp'])){
    //pembolehubah untuk memegang data yang dihantar
    $nama = $_POST['nama'];
    $ndp = $_POST['ndp'];
    $course = $_POST['course'];
    $sem = $_POST['sem'];

    //tambah rekod baru ke dalam table
    $rekod = "INSERT INTO masuk (nama,ndp,course,sem)
    VALUES ('$nama', '$ndp', '$course', '$sem')";

    //Melaksanakan pertanyaan rekod dengan sambungan ke pangkalan data
    $hasil = mysqli_query($samb, $rekod);

    //semak untuk melihat jika ada sebarang rekod dalam pangkalan data
    //papar mesej berjaya atau gagal simpan rekod baru
    if ($hasil){
        echo "<script>alert('PENDAFTARAN BERJAYA');
        window.location='list.php'</script>";   
    }else{
        echo "<script>alert('PENDAFTARAN GAGAL!');
        window.location='dashboard_pentadbir.php'</script>";
    }
}
?>

<html>
<head>
    <link rel="stylesheet" href="mycart.css">
    <style>
        .container {
            background-color: cornflowerblue;
        }

        .container ul li {
            background-color: white;
            height: 330px;
        }

        img {
            width: 70px;
            height: 70px;
        }

        h4 {
            text-align: center;
            background-color: darksalmon;
        }

        .troli {
            position: relative;
            bottom: 50px;
            left: 1100px;
            height: 40px;
        }

        p {
            font-size: 15px;
        }

        svg {
            position: absolute;
            left: 80em;
            top: 10px;
        }

        .list {
            position: absolute;
            left: 46em;
            top: 35px;
            letter-spacing: 4px;
        }
    </style>

</head>
<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">

<body>
    <table>
        <div class="navigation">
            <h1>SISTEM TEMPAHAN BARANG DI KIOSK ILP</h1>
            <nav>
                <ul>
                    <li class="list">Home
                        | Products
                        | Contact</li>
                </ul>
            </nav>
        </div>
        <svg xmlns="http://www.w3.org/2000/svg" width="26" height="26" fill="currentColor" class="bi bi-cart4"
            viewBox="0 0 16 16">
            <path
                d="M0 2.5A.5.5 0 0 1 .5 2H2a.5.5 0 0 1 .485.379L2.89 4H14.5a.5.5 0 0 1 .485.621l-1.5 6A.5.5 0 0 1 13 11H4a.5.5 0 0 1-.485-.379L1.61 3H.5a.5.5 0 0 1-.5-.5zM3.14 5l.5 2H5V5H3.14zM6 5v2h2V5H6zm3 0v2h2V5H9zm3 0v2h1.36l.5-2H12zm1.11 3H12v2h.61l.5-2zM11 8H9v2h2V8zM8 8H6v2h2V8zM5 8H3.89l.5 2H5V8zm0 5a1 1 0 1 0 0 2 1 1 0 0 0 0-2zm-2 1a2 2 0 1 1 4 0 2 2 0 0 1-4 0zm9-1a1 1 0 1 0 0 2 1 1 0 0 0 0-2zm-2 1a2 2 0 1 1 4 0 2 2 0 0 1-4 0z" />
        </svg>
        <div class="container">
            <ul>
                <li><i class="material-icons">favorite</i>
                    <h4>PEN JENAMA FABER CASTELL</h4>
                    <img src="pen.jpg" alt="">
                    <p>price : <br>
                        RM 3.50 <br> Merah <br>Biru <br> Hitam</p>
                    <button>Add to cart<a href="list.php"></a></button>
                </li>

                <li><i class="material-icons">favorite</i>
                    <h4>FOOLSCAP PAPER</h4>
                    <img src="kertas.jpg" alt="">
                    <p>price : <br>
                        RM 5.80</p>
                    <button>Add to cart<a href="list.php"></a></button>
                </li>

                <li><i class="material-icons">favorite</i>
                    <h4>CORRECTION TAPE</h4>
                    <img src="tape.jpg" alt="">
                    <p>price : <br>
                        RM 4.30</p>
                    <button>Add to cart<a href="list.php"></a></button>
                </li>

                <li>
                    <i class="material-icons">favorite</i>
                    <h4>DOWNY PREMIUM PARFUM</h4>
                    <img src="downy.jpg" alt="">
                    <p>price : <br>
                        RM 13.90</p>
                    <button>Add to cart<a href="list.php"></a></button>
                </li>

                <li><i class="material-icons">favorite</i>
                    <h4>PILOT WHITEBOARD MARKER</h4>
                    <img src="marker.jpg" alt="">
                    <p>price : RM 25.90 <br>
                        colour : <br> Biru <br> Hitam <br> Merah <br> Orange <br> Hijau <br> Purple </p>
                    <button>Add to cart<a href="list.php"></a></button>
                </li>

                <li><i class="material-icons">favorite</i>
                    <h4>NOTEBOOK</h4>
                    <img src="notebook.jpg" alt="">
                    <p>price : <br>
                        RM 10.60</p>
                    <button>Add to cart<a href="list.php"></a></button>
                </li>
            </ul>
        </div>
    </table>
    </form>

</body>

</html>