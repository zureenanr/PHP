<?php
include "config.php";
if (isset($_POST['ndp'])){

    $nama = $_POST['nama'];
    $ndp = $_POST['ndp'];
    $course = $_POST['course'];
    $sem = $_POST['sem'];

    $rekod = "INSERT INTO masuk (nama,ndp,course,sem)
    VALUES ('$nama', '$ndp', '$course', '$sem')";

    $hasil = mysqli_query($samb, $rekod);

    if ($hasil){
        echo "<script>alert('PENDAFTARAN BERJAYA');
        window.location='mycart.php'</script>";   
    }else{
        echo "<script>alert('PENDAFTARAN GAGAL!');
        window.location='login.php'</script>";
    }
}
?>
<!DOCTYPE html>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
<html>
    <head>
        <style>
    body {
        background-color: rgb(142, 212, 226);
        display: flex;
        justify-content: center;
        align-items: center;
        height: 100vh;
        }   

        *{
        font-family: Georgia, 'Times New Roman', Times, serif;
            box-sizing: border-box;
        }

    form {
        width: 500px;
        border: 2px solid rgb(204, 75, 75);
        padding: 30px;
        background: rgb(74, 201, 233);
        border-radius: 15px;
        }

    h2 {
        text-align: center;
        margin-bottom: 40px;
        font-style: italic;
        }

    input {
        display: block;
        border: 2px solid rgb(80, 233, 238);
        width: 95%;
        padding: 10px;
        margin: 10px auto;
        border-radius: 5px;
        } 

    label {
        color: black;
        font-size: 14px;
        padding: 10px;
        }  

    button {
        float: right;
        /* background: rgb(221, 20, 20); */
        padding: 10px 15px;
        color: #fff;
        border-radius: 5px;
        margin-right: 10px;
        border: none;
        }

    button:hover {
        opacity: .7;
        }

    select {
        float: left;
        padding: 10px 11px;
        border-radius: 5px;
        margin-right: 12px;
        }
        </style>

<title>LOGIN</title>
<link rel="stylesheet" href="index.css">
        
    </head>
    <body>
        <form action="login.php" method="post">
            <h2>LOGIN <br> KIOSK PELAJAR ILP</h2>
            <label>Name</label>
            <input type="text" name="nama" placeholder="User Name">

            <label> No. NDP</label>
            <input type="ndp" name="ndp" placeholder="No. NDP">

            <label>Nama Course</label><br>
                <select name="course" required>
                <option value="">--Pilih--</option>
                <option value="TKR">TKR</option>
                <option value="TPP">TPP</option>
                <option value="TPM">TPM</option>
                <option value="CADD">CADD</option>
            </select><br><br>

            <label>Semester</label><br>
                <select name="sem" required>
                <option value="1">1</option>
                <option value="2">2</option>
                <option value="3">3</option>
                <option value="4">4</option>
                <option value="5">5</option>
            </select><br><br>
            
            <button type="submit" class="btn btn-success">Login</button>
            <button type="reset" class="btn btn-secondary">Reset</button><br><br>
        </form>
    </body>