<?php
include "config.php";
if (isset($_POST['ndp'])){
    //pembolehubah untuk memegang data yang dihantar
    $nama = $_POST['nama'];
    $ndp = $_POST['ndp'];
    $course = $_POST['course'];
    $sem = $_POST['sem'];

    //tambah rekod baru ke dalam table
    $rekod = "INSERT INTO masuk (nama,ndp,course,sem)
    VALUES ('$nama', '$ndp', '$course', '$sem')";

    //Melaksanakan pertanyaan rekod dengan sambungan ke pangkalan data
    $hasil = mysqli_query($samb, $rekod);

    //semak untuk melihat jika ada sebarang rekod dalam pangkalan data
    //papar mesej berjaya atau gagal simpan rekod baru
    if ($hasil){
        echo "<script>alert('PENDAFTARAN BERJAYA');
        window.location='dashboard_pentadbir.php'</script>";   
    }else{
        echo "<script>alert('PENDAFTARAN GAGAL!');
        window.location='dashboard_pentadbir.php'</script>";
    }
}
?>
<html>
<head><link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
<style>
    .ayu{
        border : 2px black solid;
        padding: 10px;
    }
    .img1{
        height: 100px;
        width: 100px;
    }
    .img2{
        height: 100px;
        width: 100px;
    }
    .img3{
        height: 100px;
        width: 100px;
    }
    .img4{
        height: 100px;
        width: 100px;
    }


</style>
</head>
        <body>
        <div class="container mt-5 p-3 rounded cart">
        <div class="row no-gutters">
            <div class="col-md-8">
                <div class="product-details mr-2">
                    <div class="d-flex flex-row align-items-center"><i class="fa fa-long-arrow-left"></i><span class="ml-2">Continue Shopping</span></div>
                    <hr>
                    <h6 class="mb-0">Shopping Cart</h6>
                    <span>You have 4 items in your cart</span>
                        <div class="d-flex flex-row align-items-center"><span class="text-black-50">Sort by:</span>
                            <div class="price ml-2"><span class="mr-1">Price</span><i class="fa fa-angle-down"></i></div>
                        </div>
                    </div>
                    <br>
                    
                    <div class="a">
                        <img class="img1" src="downy.jpg" width="40">
                            <div class="ml-2"><span class="font-weight-bold d-block">Downy Refill 530ml Daring or Downy Refill 530ml <br></span><span class="spec">Price : 13.90</span>
                        </div>
                        <br>

                    <div class="b">
                        <img class="img2" src="pen.jpg" width="40">
                            <div class="ml-2"><span class="font-weight-bold d-block">Faber Castell Grip X Ball Pen <br></span><span class="spec">Price : 5.30</span>
                        </div>
                        <br>

                    <div class="c">
                        <img class="img3" src="marker.jpg" width="40">
                            <div class="ml-2"><span class="font-weight-bold d-block">Pilot whiteboard marker refillable with ink. Non toxic whiteboard marker for kids. Whiteboard with marker and eraser.<br></span><span class="spec">Price : 25.90</span>
                        </div>
                        <br>

                    <div class="d">
                        <img class="img4" src="tape.jpg" width="40">
                            <div class="ml-2"><span class="font-weight-bold d-block">5MM tape width correction tape with one refill. No peculiar and smell non-toxic.<br></span><span class="spec">Price : 4.30</span>
                        </div>
                </div>
            </div>
            <br>

                <div class="payment-info">
                    <span><h1>PAYMENT METHOD</h1></span> <div class="ayu"><span class="type d-block mt-3 mb-1">Card type</span><label class="radio"> <input type="radio" name="card" value="payment" checked> <span><img width="30" src="https://img.icons8.com/color/48/000000/mastercard.png"/></span> </label>

<label class="radio"> <input type="radio" name="card" value="payment"> <span><img width="30" src="https://img.icons8.com/officel/48/000000/visa.png"/></span> </label>

<label class="radio"> <input type="radio" name="card" value="payment"> <span><img width="30" src="https://img.icons8.com/ultraviolet/48/000000/amex.png"/></span> </label>


<label class="radio"> <input type="radio" name="card" value="payment"> <span><img width="30" src="https://img.icons8.com/officel/48/000000/paypal.png"/></span> </label>
                    <div><label class="credit-card-label">Name on card</label><input type="text" class="form-control credit-inputs" placeholder="Name"></div>
                    <div><label class="credit-card-label">Card number</label><input type="text" class="form-control credit-inputs" placeholder="0000 0000 0000 0000"></div>
                    <div class="row">
                        <div class="col-md-6"><label class="credit-card-label">Date</label><input type="text" class="form-control credit-inputs" placeholder="12/24"></div>
                        <div class="col-md-6"><label class="credit-card-label">CVV</label><input type="text" class="form-control credit-inputs" placeholder="342"></div>
                    </div>
                    <hr class="line">
                    <div class="d-flex justify-content-between information"><span>Subtotal</span><span>$49.40</span></div>
                    <div class="d-flex justify-content-between information"><span>Shipping</span><span>$1.00</span></div>
                    <div class="d-flex justify-content-between information"><span>Total(Incl. taxes)</span><span>$50.40</span></div><button class="btn btn-primary btn-block d-flex justify-content-between mt-3" type="button"><span>$50.40</span><span> Checkout<i class="fa fa-long-arrow-right ml-1"></i></span></button></div>
            </div>
        </div>
</div>
        </body>
  
</html>